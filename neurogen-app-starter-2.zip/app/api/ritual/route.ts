import { NextResponse } from 'next/server'
import OpenAI from 'openai'
import { SYSTEM_PROMPT, RITUAL_TEMPLATE } from '@/lib/prompt'
export async function POST(request: Request) {
  try {
    const { goal } = await request.json()
    if (!goal || typeof goal !== 'string') return NextResponse.json({ error: 'Missing goal' }, { status: 400 })
    const apiKey = process.env.OPENAI_API_KEY
    const model = process.env.OPENAI_MODEL || 'gpt-4o'
    if (!apiKey) {
      return NextResponse.json({ 
        text: null,
        template: `Title: ${goal}
Duration: ≤2 minutes

PLAIN (do this):
[breathe] One slow breath.
[mirror] “What matters in the next 5 minutes?”
[shift] From spinning to single-task.
[install] “I move one piece forward.”

MYTHIC (same function, symbolic):
[ritual] Place your palm on your chest — claim the center.
[identity] The Anchor.
[install] “I hold fast; the storm passes.”`
      })
    }
    const client = new OpenAI({ apiKey })
    const completion = await client.chat.completions.create({
      model, temperature: 0.7,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: RITUAL_TEMPLATE(goal) }
      ]
    })
    const text = completion.choices[0]?.message?.content ?? ''
    return NextResponse.json({ text })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? 'Unknown error' }, { status: 500 })
  }
}
