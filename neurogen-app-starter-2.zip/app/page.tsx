import Link from 'next/link'
import { ShimmerCard } from '@/components/ShimmerCard'
import { RitualForm } from '@/components/RitualForm'
export default function Home() {
  return (
    <div className="space-y-8">
      <section className="card p-8">
        <h1 className="text-3xl font-semibold">NEUROGEN Mentor</h1>
        <p className="text-white/80 mt-2">Shift out of stress, anxiety, or overwhelm in under 2 minutes. Plain English first; mythic optional.</p>
        <div className="mt-4 flex gap-3">
          <Link href="/pricing" className="btn">Membership $4.99/mo</Link>
          <Link href="/dashboard" className="btn">Open Dashboard</Link>
        </div>
      </section>
      <div className="grid md:grid-cols-2 gap-6">
        <ShimmerCard />
        <RitualForm />
      </div>
    </div>
  )
}
