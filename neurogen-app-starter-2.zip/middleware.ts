import { authMiddleware } from "@clerk/nextjs";
export default authMiddleware({ publicRoutes: ["/", "/pricing", "/api/ritual", "/api/shimmer"] });
export const config = { matcher: ["/((?!_next|.*\..*).*)"] };
