'use client';
import { useState } from 'react';
export function RitualForm() {
  const [goal, setGoal] = useState('calm under pressure');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setOutput('');
    try {
      const res = await fetch('/api/ritual', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ goal })
      });
      const data = await res.json();
      setOutput(data.text || data.template);
    } catch (err) {
      setOutput('Error generating ritual. Showing offline template.\n\n' + offline(goal));
    } finally {
      setLoading(false);
    }
  };
  const offline = (g: string) => `Title: ${g}
Duration: ≤2 minutes

PLAIN (do this):
[breathe] One slow breath.
[mirror] “What matters in the next 5 minutes?”
[shift] From spinning to single-task.
[install] “I move one piece forward.”

MYTHIC (same function, symbolic):
[ritual] Place your palm on your chest — claim the center.
[identity] The Anchor.
[install] “I hold fast; the storm passes.”`;
  return (
    <div className="card p-6 space-y-3">
      <h3 className="text-lg font-semibold">Generate a Ritual</h3>
      <form onSubmit={submit} className="flex gap-2">
        <input className="input" value={goal} onChange={e=>setGoal(e.target.value)} placeholder="goal (e.g., calm, focus, courage)" />
        <button className="btn" disabled={loading}>{loading ? 'Creating…' : 'Create'}</button>
      </form>
      <pre className="text-sm whitespace-pre-wrap bg-black/30 p-4 rounded-xl border border-white/10 min-h-[160px]">{output}</pre>
    </div>
  );
}
